﻿namespace inventoryManagement
{
    partial class ManageCategories
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            DataGridViewCellStyle dataGridViewCellStyle1 = new DataGridViewCellStyle();
            panel1 = new Panel();
            label3 = new Label();
            label2 = new Label();
            label1 = new Label();
            panel2 = new Panel();
            CatName = new TextBox();
            CatID = new TextBox();
            button4 = new Button();
            button3 = new Button();
            button1 = new Button();
            CategoryData = new DataGridView();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)CategoryData).BeginInit();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.BackColor = Color.Turquoise;
            panel1.Controls.Add(label3);
            panel1.Controls.Add(label2);
            panel1.Controls.Add(label1);
            panel1.Dock = DockStyle.Top;
            panel1.Location = new Point(0, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(1162, 124);
            panel1.TabIndex = 2;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            label3.Location = new Point(1122, 9);
            label3.Name = "label3";
            label3.Size = new Size(28, 32);
            label3.TabIndex = 2;
            label3.Text = "X";
            label3.Click += label3_Click;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 14F, FontStyle.Bold, GraphicsUnit.Point);
            label2.Location = new Point(498, 72);
            label2.Name = "label2";
            label2.Size = new Size(269, 38);
            label2.TabIndex = 1;
            label2.Text = "Manage Categories";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI Black", 16F, FontStyle.Bold, GraphicsUnit.Point);
            label1.Location = new Point(367, 15);
            label1.Name = "label1";
            label1.Size = new Size(511, 45);
            label1.TabIndex = 0;
            label1.Text = "Inventory Management System";
            // 
            // panel2
            // 
            panel2.BackColor = Color.Turquoise;
            panel2.Location = new Point(0, 548);
            panel2.Name = "panel2";
            panel2.Size = new Size(1162, 24);
            panel2.TabIndex = 3;
            // 
            // CatName
            // 
            CatName.Font = new Font("Segoe UI", 11F, FontStyle.Bold, GraphicsUnit.Point);
            CatName.Location = new Point(338, 244);
            CatName.Name = "CatName";
            CatName.Size = new Size(211, 37);
            CatName.TabIndex = 7;
            CatName.Text = "Category Name";
            // 
            // CatID
            // 
            CatID.Font = new Font("Segoe UI", 11F, FontStyle.Bold, GraphicsUnit.Point);
            CatID.Location = new Point(53, 244);
            CatID.Name = "CatID";
            CatID.Size = new Size(211, 37);
            CatID.TabIndex = 6;
            CatID.Text = "CategoryID";
            CatID.UseWaitCursor = true;
            CatID.TextChanged += CusomerID_TextChanged;
            // 
            // button4
            // 
            button4.BackColor = Color.MediumTurquoise;
            button4.Font = new Font("Segoe UI", 10F, FontStyle.Bold, GraphicsUnit.Point);
            button4.Location = new Point(201, 390);
            button4.Name = "button4";
            button4.Size = new Size(211, 46);
            button4.TabIndex = 14;
            button4.Text = "Home";
            button4.UseVisualStyleBackColor = false;
            button4.Click += button4_Click;
            // 
            // button3
            // 
            button3.BackColor = Color.MediumTurquoise;
            button3.Font = new Font("Segoe UI", 10F, FontStyle.Bold, GraphicsUnit.Point);
            button3.Location = new Point(338, 313);
            button3.Name = "button3";
            button3.Size = new Size(211, 46);
            button3.TabIndex = 13;
            button3.Text = "Delete";
            button3.UseVisualStyleBackColor = false;
            button3.Click += button3_Click;
            // 
            // button1
            // 
            button1.BackColor = Color.MediumTurquoise;
            button1.Font = new Font("Segoe UI", 10F, FontStyle.Bold, GraphicsUnit.Point);
            button1.Location = new Point(53, 313);
            button1.Name = "button1";
            button1.Size = new Size(211, 46);
            button1.TabIndex = 12;
            button1.Text = "Add";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // CategoryData
            // 
            CategoryData.BackgroundColor = Color.LightCyan;
            CategoryData.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            CategoryData.GridColor = SystemColors.Control;
            CategoryData.Location = new Point(615, 172);
            CategoryData.Name = "CategoryData";
            CategoryData.RowHeadersWidth = 62;
            dataGridViewCellStyle1.BackColor = Color.FromArgb(0, 192, 192);
            dataGridViewCellStyle1.ForeColor = Color.Black;
            CategoryData.RowsDefaultCellStyle = dataGridViewCellStyle1;
            CategoryData.RowTemplate.Height = 33;
            CategoryData.Size = new Size(517, 354);
            CategoryData.TabIndex = 15;
            // 
            // ManageCategories
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.Azure;
            ClientSize = new Size(1162, 571);
            Controls.Add(CategoryData);
            Controls.Add(button4);
            Controls.Add(button3);
            Controls.Add(button1);
            Controls.Add(CatName);
            Controls.Add(CatID);
            Controls.Add(panel2);
            Controls.Add(panel1);
            FormBorderStyle = FormBorderStyle.None;
            Name = "ManageCategories";
            Text = "ManageCategories";
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)CategoryData).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Panel panel1;
        private Label label3;
        private Label label2;
        private Label label1;
        private Panel panel2;
        private TextBox CatName;
        private TextBox CatID;
        private Button button4;
        private Button button3;
        private Button button1;
        private DataGridView CategoryData;
    }
}