﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace inventoryManagement
{
    public partial class ManageCategories : Form
    {
        SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=""D:\Uni\OS Lab\Final Project\inventoryManagement\inventoryManagement\inventorydb.mdf"";Integrated Security=True");
        public ManageCategories()
        {
            InitializeComponent();
            this.Load += new EventHandler(ManageCategories_Load);
        }
        private void LoadCategoryData()
        {
            try
            {
                string query = "SELECT * FROM [Category]";
                SqlDataAdapter sda = new SqlDataAdapter(query, con);
                DataTable dt = new DataTable();
                sda.Fill(dt);
                CategoryData.DataSource = dt;
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred: " + ex.Message);
            }
        }
        private void ManageCategories_Load(object sender, EventArgs e)
        {
            LoadCategoryData();
        }

        private void CusomerID_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                using (SqlCommand cmd = new SqlCommand("INSERT INTO [Category] (CatId,CatName) VALUES (@CatId, @CatName)", con))
                {
                    cmd.Parameters.AddWithValue("@CatId", CatID.Text);
                    cmd.Parameters.AddWithValue("@CatName", CatName.Text);
                    con.Open();
                    int rowsAffected = cmd.ExecuteNonQuery();
                    con.Close();
                    LoadCategoryData();
                    if (rowsAffected > 0)
                    {
                        MessageBox.Show("Category added successfully.");
                    }
                    else
                    {
                        MessageBox.Show("Category addition failed.");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred: " + ex.Message);
            }
        }

        private void label3_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (CatID.Text == "")
            {
                MessageBox.Show("please enter Category ID");
            }
            else
            {
                con.Open();
                string delQuery = "delete from [Category] where CatId ='" + CatID.Text + "'";
                SqlCommand cmd = new SqlCommand(delQuery, con);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Category deleted successfully.");
                con.Close();
                LoadCategoryData();
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            menu mn = new menu();
            mn.Show();
            this.Hide();
        }
    }
}
