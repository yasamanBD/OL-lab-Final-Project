﻿namespace inventoryManagement
{
    partial class ManageCustomers
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            DataGridViewCellStyle dataGridViewCellStyle1 = new DataGridViewCellStyle();
            label2 = new Label();
            label1 = new Label();
            panel1 = new Panel();
            label3 = new Label();
            CustomerPhone = new TextBox();
            customerName = new TextBox();
            CusomerID = new TextBox();
            button4 = new Button();
            button3 = new Button();
            button1 = new Button();
            panel2 = new Panel();
            customerdata = new DataGridView();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)customerdata).BeginInit();
            SuspendLayout();
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 14F, FontStyle.Bold, GraphicsUnit.Point);
            label2.Location = new Point(498, 72);
            label2.Name = "label2";
            label2.Size = new Size(269, 38);
            label2.TabIndex = 1;
            label2.Text = "Manage Customers";
            label2.Click += label2_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI Black", 16F, FontStyle.Bold, GraphicsUnit.Point);
            label1.Location = new Point(367, 15);
            label1.Name = "label1";
            label1.Size = new Size(511, 45);
            label1.TabIndex = 0;
            label1.Text = "Inventory Management System";
            // 
            // panel1
            // 
            panel1.BackColor = Color.Turquoise;
            panel1.Controls.Add(label3);
            panel1.Controls.Add(label2);
            panel1.Controls.Add(label1);
            panel1.Dock = DockStyle.Top;
            panel1.Location = new Point(0, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(1184, 124);
            panel1.TabIndex = 1;
            panel1.Paint += panel1_Paint;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            label3.Location = new Point(1144, 9);
            label3.Name = "label3";
            label3.Size = new Size(28, 32);
            label3.TabIndex = 2;
            label3.Text = "X";
            label3.Click += label3_Click;
            // 
            // CustomerPhone
            // 
            CustomerPhone.Font = new Font("Segoe UI", 11F, FontStyle.Bold, GraphicsUnit.Point);
            CustomerPhone.Location = new Point(49, 254);
            CustomerPhone.Name = "CustomerPhone";
            CustomerPhone.Size = new Size(211, 37);
            CustomerPhone.TabIndex = 6;
            CustomerPhone.Text = "Customer Phone";
            // 
            // customerName
            // 
            customerName.Font = new Font("Segoe UI", 11F, FontStyle.Bold, GraphicsUnit.Point);
            customerName.Location = new Point(334, 182);
            customerName.Name = "customerName";
            customerName.Size = new Size(211, 37);
            customerName.TabIndex = 5;
            customerName.Text = "Customer Name";
            // 
            // CusomerID
            // 
            CusomerID.Font = new Font("Segoe UI", 11F, FontStyle.Bold, GraphicsUnit.Point);
            CusomerID.Location = new Point(49, 182);
            CusomerID.Name = "CusomerID";
            CusomerID.Size = new Size(211, 37);
            CusomerID.TabIndex = 4;
            CusomerID.Text = "CusomerID";
            CusomerID.UseWaitCursor = true;
            // 
            // button4
            // 
            button4.BackColor = Color.MediumTurquoise;
            button4.Font = new Font("Segoe UI", 10F, FontStyle.Bold, GraphicsUnit.Point);
            button4.Location = new Point(197, 399);
            button4.Name = "button4";
            button4.Size = new Size(211, 46);
            button4.TabIndex = 11;
            button4.Text = "Home";
            button4.UseVisualStyleBackColor = false;
            button4.Click += button4_Click;
            // 
            // button3
            // 
            button3.BackColor = Color.MediumTurquoise;
            button3.Font = new Font("Segoe UI", 10F, FontStyle.Bold, GraphicsUnit.Point);
            button3.Location = new Point(334, 322);
            button3.Name = "button3";
            button3.Size = new Size(211, 46);
            button3.TabIndex = 10;
            button3.Text = "Delete";
            button3.UseVisualStyleBackColor = false;
            button3.Click += button3_Click;
            // 
            // button1
            // 
            button1.BackColor = Color.MediumTurquoise;
            button1.Font = new Font("Segoe UI", 10F, FontStyle.Bold, GraphicsUnit.Point);
            button1.Location = new Point(49, 322);
            button1.Name = "button1";
            button1.Size = new Size(211, 46);
            button1.TabIndex = 9;
            button1.Text = "Add";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // panel2
            // 
            panel2.BackColor = Color.Turquoise;
            panel2.Location = new Point(0, 597);
            panel2.Name = "panel2";
            panel2.Size = new Size(1184, 30);
            panel2.TabIndex = 12;
            // 
            // customerdata
            // 
            customerdata.BackgroundColor = Color.LightCyan;
            customerdata.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            customerdata.GridColor = SystemColors.Control;
            customerdata.Location = new Point(642, 182);
            customerdata.Name = "customerdata";
            customerdata.RowHeadersWidth = 62;
            dataGridViewCellStyle1.BackColor = Color.FromArgb(0, 192, 192);
            dataGridViewCellStyle1.ForeColor = Color.Black;
            customerdata.RowsDefaultCellStyle = dataGridViewCellStyle1;
            customerdata.RowTemplate.Height = 33;
            customerdata.Size = new Size(517, 354);
            customerdata.TabIndex = 13;
            // 
            // ManageCustomers
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.Azure;
            ClientSize = new Size(1184, 627);
            Controls.Add(customerdata);
            Controls.Add(panel2);
            Controls.Add(button4);
            Controls.Add(button3);
            Controls.Add(button1);
            Controls.Add(CustomerPhone);
            Controls.Add(panel1);
            Controls.Add(customerName);
            Controls.Add(CusomerID);
            FormBorderStyle = FormBorderStyle.None;
            Name = "ManageCustomers";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "ManageCustomers";
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)customerdata).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label2;
        private Label label1;
        private Panel panel1;
        private Label label3;
        private TextBox CustomerPhone;
        private TextBox customerName;
        private TextBox CusomerID;
        private Button button4;
        private Button button3;
        private Button button1;
        private Panel panel2;
        private DataGridView customerdata;
    }
}