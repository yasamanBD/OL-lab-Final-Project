﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;

namespace inventoryManagement
{
    public partial class ManageCustomers : Form
    {
        SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=""D:\Uni\OS Lab\Final Project\inventoryManagement\inventoryManagement\inventorydb.mdf"";Integrated Security=True");
        public ManageCustomers()
        {
            InitializeComponent();
            this.Load += new EventHandler(ManageCustomers_Load);
        }
        private void LoadCustomerData()
        {
            try
            {
                string query = "SELECT * FROM [Customer]";
                SqlDataAdapter sda = new SqlDataAdapter(query, con);
                DataTable dt = new DataTable();
                sda.Fill(dt);
                customerdata.DataSource = dt;
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred: " + ex.Message);
            }
        }
        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                using (SqlCommand cmd = new SqlCommand("INSERT INTO [Customer] (CustId,Custname, Custphone) VALUES (@CustId, @Custname, @Custphone)", con))
                {
                    cmd.Parameters.AddWithValue("@CustId", CusomerID.Text);
                    cmd.Parameters.AddWithValue("@Custname", customerName.Text);
                    cmd.Parameters.AddWithValue("@Custphone", CustomerPhone.Text);
                    con.Open();
                    int rowsAffected = cmd.ExecuteNonQuery();
                    con.Close();
                    LoadCustomerData();
                    if (rowsAffected > 0)
                    {
                        MessageBox.Show("Customer added successfully.");
                    }
                    else
                    {
                        MessageBox.Show("Customer addition failed.");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred: " + ex.Message);
            }
        }

        private void label3_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (CusomerID.Text == "")
            {
                MessageBox.Show("please enter Customer ID");
            }
            else
            {
                con.Open();
                string delQuery = "delete from [Customer] where CustId ='" + CusomerID.Text + "'";
                SqlCommand cmd = new SqlCommand(delQuery, con);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Customer deleted successfully.");
                con.Close();
                LoadCustomerData();
            }
        }
        private void ManageCustomers_Load(object sender, EventArgs e)
        {
            LoadCustomerData();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            menu mn = new menu();
            mn.Show();
            this.Hide();
        }
    }
}
