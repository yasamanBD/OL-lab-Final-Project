﻿namespace inventoryManagement
{
    partial class ManageOrders
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            DataGridViewCellStyle dataGridViewCellStyle1 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle2 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle3 = new DataGridViewCellStyle();
            panel1 = new Panel();
            label3 = new Label();
            label2 = new Label();
            label1 = new Label();
            customerdata = new DataGridView();
            label4 = new Label();
            dateTimePicker1 = new DateTimePicker();
            CustomerID = new TextBox();
            OrderID = new TextBox();
            label5 = new Label();
            productData = new DataGridView();
            searchCombo = new ComboBox();
            refresh = new Button();
            Search = new Button();
            CustomerName = new TextBox();
            label6 = new Label();
            qty = new TextBox();
            AddToOrder = new Button();
            orderGridView = new DataGridView();
            Num = new DataGridViewTextBoxColumn();
            Product = new DataGridViewTextBoxColumn();
            Quantity = new DataGridViewTextBoxColumn();
            Uprice = new DataGridViewTextBoxColumn();
            TotalPrice = new DataGridViewTextBoxColumn();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)customerdata).BeginInit();
            ((System.ComponentModel.ISupportInitialize)productData).BeginInit();
            ((System.ComponentModel.ISupportInitialize)orderGridView).BeginInit();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.BackColor = Color.Turquoise;
            panel1.Controls.Add(label3);
            panel1.Controls.Add(label2);
            panel1.Controls.Add(label1);
            panel1.Dock = DockStyle.Top;
            panel1.Location = new Point(0, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(1140, 124);
            panel1.TabIndex = 4;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            label3.Location = new Point(1100, 15);
            label3.Name = "label3";
            label3.Size = new Size(28, 32);
            label3.TabIndex = 2;
            label3.Text = "X";
            label3.Click += label3_Click;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 14F, FontStyle.Bold, GraphicsUnit.Point);
            label2.Location = new Point(498, 72);
            label2.Name = "label2";
            label2.Size = new Size(218, 38);
            label2.TabIndex = 1;
            label2.Text = "Manage Orders";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI Black", 16F, FontStyle.Bold, GraphicsUnit.Point);
            label1.Location = new Point(367, 15);
            label1.Name = "label1";
            label1.Size = new Size(511, 45);
            label1.TabIndex = 0;
            label1.Text = "Inventory Management System";
            // 
            // customerdata
            // 
            customerdata.BackgroundColor = Color.LightCyan;
            customerdata.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            customerdata.GridColor = SystemColors.Control;
            customerdata.Location = new Point(12, 197);
            customerdata.Name = "customerdata";
            customerdata.RowHeadersWidth = 62;
            dataGridViewCellStyle1.BackColor = Color.FromArgb(0, 192, 192);
            dataGridViewCellStyle1.ForeColor = Color.Black;
            customerdata.RowsDefaultCellStyle = dataGridViewCellStyle1;
            customerdata.RowTemplate.Height = 33;
            customerdata.Size = new Size(512, 141);
            customerdata.TabIndex = 5;
            customerdata.CellContentClick += customerdata_CellContentClick;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI Semibold", 10F, FontStyle.Bold, GraphicsUnit.Point);
            label4.Location = new Point(176, 147);
            label4.Name = "label4";
            label4.Size = new Size(146, 28);
            label4.TabIndex = 6;
            label4.Text = "Customers List";
            // 
            // dateTimePicker1
            // 
            dateTimePicker1.Location = new Point(181, 587);
            dateTimePicker1.Name = "dateTimePicker1";
            dateTimePicker1.Size = new Size(294, 31);
            dateTimePicker1.TabIndex = 7;
            dateTimePicker1.ValueChanged += dateTimePicker1_ValueChanged;
            // 
            // CustomerID
            // 
            CustomerID.Font = new Font("Segoe UI", 11F, FontStyle.Bold, GraphicsUnit.Point);
            CustomerID.Location = new Point(43, 431);
            CustomerID.Name = "CustomerID";
            CustomerID.Size = new Size(432, 37);
            CustomerID.TabIndex = 12;
            CustomerID.Text = "Customer ID";
            CustomerID.TextChanged += CustomerID_TextChanged;
            // 
            // OrderID
            // 
            OrderID.Font = new Font("Segoe UI", 11F, FontStyle.Bold, GraphicsUnit.Point);
            OrderID.Location = new Point(43, 361);
            OrderID.Name = "OrderID";
            OrderID.Size = new Size(432, 37);
            OrderID.TabIndex = 11;
            OrderID.Text = "Order ID";
            OrderID.TextChanged += OrderID_TextChanged;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Segoe UI", 10F, FontStyle.Regular, GraphicsUnit.Point);
            label5.ForeColor = Color.Teal;
            label5.Location = new Point(43, 589);
            label5.Name = "label5";
            label5.Size = new Size(109, 28);
            label5.TabIndex = 13;
            label5.Text = "Order Date";
            label5.Click += label5_Click;
            // 
            // productData
            // 
            productData.BackgroundColor = Color.LightCyan;
            productData.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            productData.GridColor = SystemColors.Control;
            productData.Location = new Point(530, 197);
            productData.Name = "productData";
            productData.RowHeadersWidth = 62;
            dataGridViewCellStyle2.BackColor = Color.FromArgb(0, 192, 192);
            dataGridViewCellStyle2.ForeColor = Color.Black;
            productData.RowsDefaultCellStyle = dataGridViewCellStyle2;
            productData.RowTemplate.Height = 33;
            productData.Size = new Size(598, 141);
            productData.TabIndex = 14;
            productData.CellContentClick += productData_CellContentClick;
            // 
            // searchCombo
            // 
            searchCombo.Font = new Font("Segoe UI Semibold", 10F, FontStyle.Bold, GraphicsUnit.Point);
            searchCombo.FormattingEnabled = true;
            searchCombo.Location = new Point(577, 145);
            searchCombo.Name = "searchCombo";
            searchCombo.Size = new Size(254, 36);
            searchCombo.TabIndex = 21;
            searchCombo.Text = "Select Category";
            searchCombo.SelectedIndexChanged += searchCombo_SelectedIndexChanged;
            // 
            // refresh
            // 
            refresh.BackColor = Color.MediumTurquoise;
            refresh.Font = new Font("Segoe UI", 10F, FontStyle.Bold, GraphicsUnit.Point);
            refresh.Location = new Point(965, 142);
            refresh.Name = "refresh";
            refresh.Size = new Size(109, 39);
            refresh.TabIndex = 24;
            refresh.Text = "Refresh";
            refresh.UseVisualStyleBackColor = false;
            refresh.Click += refresh_Click;
            // 
            // Search
            // 
            Search.BackColor = Color.MediumTurquoise;
            Search.Font = new Font("Segoe UI", 10F, FontStyle.Bold, GraphicsUnit.Point);
            Search.Location = new Point(850, 142);
            Search.Name = "Search";
            Search.Size = new Size(109, 39);
            Search.TabIndex = 23;
            Search.Text = "Search";
            Search.UseVisualStyleBackColor = false;
            Search.Click += Search_Click;
            // 
            // CustomerName
            // 
            CustomerName.Font = new Font("Segoe UI", 11F, FontStyle.Bold, GraphicsUnit.Point);
            CustomerName.Location = new Point(43, 509);
            CustomerName.Name = "CustomerName";
            CustomerName.Size = new Size(432, 37);
            CustomerName.TabIndex = 25;
            CustomerName.Text = "Customer Name";
            CustomerName.TextChanged += textBox1_TextChanged;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Segoe UI", 10F, FontStyle.Regular, GraphicsUnit.Point);
            label6.ForeColor = Color.Teal;
            label6.Location = new Point(577, 362);
            label6.Name = "label6";
            label6.Size = new Size(88, 28);
            label6.TabIndex = 26;
            label6.Text = "Quantity";
            label6.Click += label6_Click;
            // 
            // qty
            // 
            qty.Font = new Font("Segoe UI", 11F, FontStyle.Bold, GraphicsUnit.Point);
            qty.Location = new Point(669, 357);
            qty.Name = "qty";
            qty.Size = new Size(162, 37);
            qty.TabIndex = 27;
            // 
            // AddToOrder
            // 
            AddToOrder.BackColor = Color.MediumTurquoise;
            AddToOrder.Font = new Font("Segoe UI", 10F, FontStyle.Bold, GraphicsUnit.Point);
            AddToOrder.Location = new Point(850, 355);
            AddToOrder.Name = "AddToOrder";
            AddToOrder.Size = new Size(224, 39);
            AddToOrder.TabIndex = 28;
            AddToOrder.Text = "Add To Order";
            AddToOrder.UseVisualStyleBackColor = false;
            AddToOrder.Click += AddToOrder_Click;
            // 
            // orderGridView
            // 
            orderGridView.BackgroundColor = Color.LightCyan;
            orderGridView.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            orderGridView.Columns.AddRange(new DataGridViewColumn[] { Num, Product, Quantity, Uprice, TotalPrice });
            orderGridView.GridColor = SystemColors.Control;
            orderGridView.Location = new Point(530, 431);
            orderGridView.Name = "orderGridView";
            orderGridView.RowHeadersWidth = 62;
            dataGridViewCellStyle3.BackColor = Color.FromArgb(0, 192, 192);
            dataGridViewCellStyle3.ForeColor = Color.Black;
            orderGridView.RowsDefaultCellStyle = dataGridViewCellStyle3;
            orderGridView.RowTemplate.Height = 33;
            orderGridView.Size = new Size(598, 187);
            orderGridView.TabIndex = 29;
            // 
            // Num
            // 
            Num.HeaderText = "Num";
            Num.MinimumWidth = 8;
            Num.Name = "Num";
            Num.Width = 150;
            // 
            // Product
            // 
            Product.HeaderText = "Product";
            Product.MinimumWidth = 8;
            Product.Name = "Product";
            Product.Width = 150;
            // 
            // Quantity
            // 
            Quantity.HeaderText = "Quantity";
            Quantity.MinimumWidth = 8;
            Quantity.Name = "Quantity";
            Quantity.Width = 150;
            // 
            // Uprice
            // 
            Uprice.HeaderText = "Uprice";
            Uprice.MinimumWidth = 8;
            Uprice.Name = "Uprice";
            Uprice.Width = 150;
            // 
            // TotalPrice
            // 
            TotalPrice.HeaderText = "TotalPrice";
            TotalPrice.MinimumWidth = 8;
            TotalPrice.Name = "TotalPrice";
            TotalPrice.Width = 150;
            // 
            // ManageOrders
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.Azure;
            ClientSize = new Size(1140, 700);
            Controls.Add(orderGridView);
            Controls.Add(AddToOrder);
            Controls.Add(qty);
            Controls.Add(label6);
            Controls.Add(CustomerName);
            Controls.Add(refresh);
            Controls.Add(Search);
            Controls.Add(searchCombo);
            Controls.Add(productData);
            Controls.Add(label5);
            Controls.Add(CustomerID);
            Controls.Add(OrderID);
            Controls.Add(dateTimePicker1);
            Controls.Add(label4);
            Controls.Add(customerdata);
            Controls.Add(panel1);
            FormBorderStyle = FormBorderStyle.None;
            Name = "ManageOrders";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "ManageOrders";
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)customerdata).EndInit();
            ((System.ComponentModel.ISupportInitialize)productData).EndInit();
            ((System.ComponentModel.ISupportInitialize)orderGridView).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Panel panel1;
        private Label label3;
        private Label label2;
        private Label label1;
        private DataGridView customerdata;
        private Label label4;
        private DateTimePicker dateTimePicker1;
        private TextBox CustomerID;
        private TextBox OrderID;
        private Label label5;
        private DataGridView productData;
        private ComboBox searchCombo;
        private Button refresh;
        private Button Search;
        private TextBox CustomerName;
        private Label label6;
        private TextBox qty;
        private Button AddToOrder;
        private DataGridView orderGridView;
        private DataGridViewTextBoxColumn Num;
        private DataGridViewTextBoxColumn Product;
        private DataGridViewTextBoxColumn Quantity;
        private DataGridViewTextBoxColumn Uprice;
        private DataGridViewTextBoxColumn TotalPrice;
    }
}