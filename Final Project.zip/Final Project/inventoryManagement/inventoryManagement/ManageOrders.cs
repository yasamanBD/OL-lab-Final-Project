﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace inventoryManagement
{
    public partial class ManageOrders : Form
    {
        int num = 0;
        int qaunty, uprice, totprice;
        string product;

        SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=""D:\Uni\OS Lab\Final Project\inventoryManagement\inventoryManagement\inventorydb.mdf"";Integrated Security=True");
        public ManageOrders()
        {
            InitializeComponent();
            this.Load += new EventHandler(ManageOrders_Load);
        }
        private void ManageOrders_Load(object sender, EventArgs e)
        {
            LoadCustomerData();
            LoadProductData();
            fillcategory();
        }
        private void LoadCustomerData()
        {
            try
            {
                string query = "SELECT * FROM [Customer]";
                SqlDataAdapter sda = new SqlDataAdapter(query, con);
                DataTable dt = new DataTable();
                sda.Fill(dt);
                customerdata.DataSource = dt;
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred: " + ex.Message);
            }
        }

        private void LoadProductData()
        {
            try
            {
                string query = "SELECT * FROM [Product]";
                SqlDataAdapter sda = new SqlDataAdapter(query, con);
                DataTable dt = new DataTable();
                sda.Fill(dt);
                productData.DataSource = dt;
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred: " + ex.Message);
            }
        }

        void fillcategory()
        {
            string query = "select * from [Category]";
            SqlCommand cmd = new SqlCommand(query, con);
            SqlDataReader rdr;
            try
            {
                con.Open();
                DataTable dt = new DataTable();
                dt.Columns.Add("CatName", typeof(string));
                rdr = cmd.ExecuteReader();
                dt.Load(rdr);
                searchCombo.ValueMember = "CatName";
                searchCombo.DataSource = dt;
                con.Close();
            }
            catch
            {

            }
        }

        private void customerdata_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void searchCombo_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
        private void filterByCategory()
        {
            try
            {
                string query = "SELECT * FROM [Product] where ProdCat = '" + searchCombo.SelectedValue.ToString() + "'";
                SqlDataAdapter sda = new SqlDataAdapter(query, con);
                DataTable dt = new DataTable();
                sda.Fill(dt);
                productData.DataSource = dt;
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred: " + ex.Message);
            }
        }
        private void Search_Click(object sender, EventArgs e)
        {
            filterByCategory();
        }

        private void refresh_Click(object sender, EventArgs e)
        {
            LoadProductData();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {
        }

        private void OrderID_TextChanged(object sender, EventArgs e)
        {
        }

        private void CustomerID_TextChanged(object sender, EventArgs e)
        {
        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {
        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void productData_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            product = productData.SelectedRows[0].Cells[1].Value.ToString();
            //qaunty = Convert.ToInt32(qty.Text);
            uprice = Convert.ToInt32(productData.SelectedRows[0].Cells[3].Value.ToString());
            //totprice = qaunty * uprice;
            flag = 1;
        }
        int flag = 0;
        private void AddToOrder_Click(object sender, EventArgs e)
        {
            if (qty.Text == "")
            {
                MessageBox.Show("please enter quantity of products");
            }
            else if (flag == 0)
            {
                MessageBox.Show("select product");
            }
            else
            {
                num = num + 1;
                qaunty = Convert.ToInt32(qty.Text);
                totprice = qaunty * uprice;


            }
        }
    }
}
