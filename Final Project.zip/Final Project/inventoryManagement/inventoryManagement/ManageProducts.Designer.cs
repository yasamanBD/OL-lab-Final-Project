﻿namespace inventoryManagement
{
    partial class ManageProducts
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            DataGridViewCellStyle dataGridViewCellStyle1 = new DataGridViewCellStyle();
            panel1 = new Panel();
            label3 = new Label();
            label2 = new Label();
            label1 = new Label();
            button4 = new Button();
            button3 = new Button();
            button1 = new Button();
            ProductPrice = new TextBox();
            ProductQuantity = new TextBox();
            ProductName = new TextBox();
            ProductID = new TextBox();
            ProductDesceription = new TextBox();
            productData = new DataGridView();
            panel2 = new Panel();
            Catcombo = new ComboBox();
            searchCombo = new ComboBox();
            Search = new Button();
            refresh = new Button();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)productData).BeginInit();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.BackColor = Color.Turquoise;
            panel1.Controls.Add(label3);
            panel1.Controls.Add(label2);
            panel1.Controls.Add(label1);
            panel1.Dock = DockStyle.Top;
            panel1.Location = new Point(0, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(1140, 124);
            panel1.TabIndex = 3;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            label3.Location = new Point(1100, 15);
            label3.Name = "label3";
            label3.Size = new Size(28, 32);
            label3.TabIndex = 2;
            label3.Text = "X";
            label3.Click += label3_Click;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 14F, FontStyle.Bold, GraphicsUnit.Point);
            label2.Location = new Point(498, 72);
            label2.Name = "label2";
            label2.Size = new Size(246, 38);
            label2.TabIndex = 1;
            label2.Text = "Manage Products";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI Black", 16F, FontStyle.Bold, GraphicsUnit.Point);
            label1.Location = new Point(367, 15);
            label1.Name = "label1";
            label1.Size = new Size(511, 45);
            label1.TabIndex = 0;
            label1.Text = "Inventory Management System";
            // 
            // button4
            // 
            button4.BackColor = Color.MediumTurquoise;
            button4.Font = new Font("Segoe UI", 10F, FontStyle.Bold, GraphicsUnit.Point);
            button4.Location = new Point(30, 598);
            button4.Name = "button4";
            button4.Size = new Size(254, 46);
            button4.TabIndex = 15;
            button4.Text = "Home";
            button4.UseVisualStyleBackColor = false;
            button4.Click += button4_Click;
            // 
            // button3
            // 
            button3.BackColor = Color.MediumTurquoise;
            button3.Font = new Font("Segoe UI", 10F, FontStyle.Bold, GraphicsUnit.Point);
            button3.Location = new Point(30, 546);
            button3.Name = "button3";
            button3.Size = new Size(254, 46);
            button3.TabIndex = 14;
            button3.Text = "Delete";
            button3.UseVisualStyleBackColor = false;
            button3.Click += button3_Click;
            // 
            // button1
            // 
            button1.BackColor = Color.MediumTurquoise;
            button1.Font = new Font("Segoe UI", 10F, FontStyle.Bold, GraphicsUnit.Point);
            button1.Location = new Point(30, 484);
            button1.Name = "button1";
            button1.Size = new Size(254, 46);
            button1.TabIndex = 13;
            button1.Text = "Add";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // ProductPrice
            // 
            ProductPrice.Font = new Font("Segoe UI", 11F, FontStyle.Bold, GraphicsUnit.Point);
            ProductPrice.Location = new Point(30, 309);
            ProductPrice.Name = "ProductPrice";
            ProductPrice.Size = new Size(254, 37);
            ProductPrice.TabIndex = 12;
            ProductPrice.Text = "Product Price";
            ProductPrice.TextChanged += ProductPrice_TextChanged;
            // 
            // ProductQuantity
            // 
            ProductQuantity.Font = new Font("Segoe UI", 11F, FontStyle.Bold, GraphicsUnit.Point);
            ProductQuantity.Location = new Point(30, 255);
            ProductQuantity.Name = "ProductQuantity";
            ProductQuantity.Size = new Size(254, 37);
            ProductQuantity.TabIndex = 11;
            ProductQuantity.Text = "Product Quantity";
            ProductQuantity.TextChanged += ProductQuantity_TextChanged;
            // 
            // ProductName
            // 
            ProductName.Font = new Font("Segoe UI", 11F, FontStyle.Bold, GraphicsUnit.Point);
            ProductName.Location = new Point(30, 202);
            ProductName.Name = "ProductName";
            ProductName.Size = new Size(254, 37);
            ProductName.TabIndex = 10;
            ProductName.Text = "Product Name";
            ProductName.TextChanged += ProductName_TextChanged;
            // 
            // ProductID
            // 
            ProductID.Font = new Font("Segoe UI", 11F, FontStyle.Bold, GraphicsUnit.Point);
            ProductID.Location = new Point(30, 149);
            ProductID.Name = "ProductID";
            ProductID.Size = new Size(254, 37);
            ProductID.TabIndex = 9;
            ProductID.Text = "Product ID";
            // 
            // ProductDesceription
            // 
            ProductDesceription.Font = new Font("Segoe UI", 11F, FontStyle.Bold, GraphicsUnit.Point);
            ProductDesceription.Location = new Point(30, 363);
            ProductDesceription.Name = "ProductDesceription";
            ProductDesceription.Size = new Size(254, 37);
            ProductDesceription.TabIndex = 16;
            ProductDesceription.Text = "Product Desceription";
            ProductDesceription.TextChanged += ProductDesceription_TextChanged;
            // 
            // productData
            // 
            productData.BackgroundColor = Color.LightCyan;
            productData.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            productData.GridColor = SystemColors.Control;
            productData.Location = new Point(313, 202);
            productData.Name = "productData";
            productData.RowHeadersWidth = 62;
            dataGridViewCellStyle1.BackColor = Color.FromArgb(0, 192, 192);
            dataGridViewCellStyle1.ForeColor = Color.Black;
            productData.RowsDefaultCellStyle = dataGridViewCellStyle1;
            productData.RowTemplate.Height = 33;
            productData.Size = new Size(796, 442);
            productData.TabIndex = 17;
            // 
            // panel2
            // 
            panel2.BackColor = Color.Turquoise;
            panel2.Location = new Point(0, 673);
            panel2.Name = "panel2";
            panel2.Size = new Size(1140, 31);
            panel2.TabIndex = 18;
            // 
            // Catcombo
            // 
            Catcombo.Font = new Font("Segoe UI", 11F, FontStyle.Bold, GraphicsUnit.Point);
            Catcombo.FormattingEnabled = true;
            Catcombo.Location = new Point(30, 420);
            Catcombo.Name = "Catcombo";
            Catcombo.Size = new Size(254, 38);
            Catcombo.TabIndex = 19;
            Catcombo.Text = "Product Category";
            Catcombo.SelectedIndexChanged += Catcombo_SelectedIndexChanged;
            // 
            // searchCombo
            // 
            searchCombo.Font = new Font("Segoe UI", 11F, FontStyle.Bold, GraphicsUnit.Point);
            searchCombo.FormattingEnabled = true;
            searchCombo.Location = new Point(434, 148);
            searchCombo.Name = "searchCombo";
            searchCombo.Size = new Size(254, 38);
            searchCombo.TabIndex = 20;
            searchCombo.Text = "Select Category";
            searchCombo.SelectedIndexChanged += searchCombo_SelectedIndexChanged;
            // 
            // Search
            // 
            Search.BackColor = Color.MediumTurquoise;
            Search.Font = new Font("Segoe UI", 10F, FontStyle.Bold, GraphicsUnit.Point);
            Search.Location = new Point(713, 146);
            Search.Name = "Search";
            Search.Size = new Size(109, 39);
            Search.TabIndex = 21;
            Search.Text = "Search";
            Search.UseVisualStyleBackColor = false;
            Search.Click += Search_Click;
            // 
            // refresh
            // 
            refresh.BackColor = Color.MediumTurquoise;
            refresh.Font = new Font("Segoe UI", 10F, FontStyle.Bold, GraphicsUnit.Point);
            refresh.Location = new Point(828, 146);
            refresh.Name = "refresh";
            refresh.Size = new Size(109, 39);
            refresh.TabIndex = 22;
            refresh.Text = "Refresh";
            refresh.UseVisualStyleBackColor = false;
            refresh.Click += refresh_Click;
            // 
            // ManageProducts
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.Azure;
            ClientSize = new Size(1140, 700);
            Controls.Add(refresh);
            Controls.Add(Search);
            Controls.Add(searchCombo);
            Controls.Add(Catcombo);
            Controls.Add(panel2);
            Controls.Add(productData);
            Controls.Add(ProductDesceription);
            Controls.Add(button4);
            Controls.Add(button3);
            Controls.Add(button1);
            Controls.Add(ProductPrice);
            Controls.Add(ProductQuantity);
            Controls.Add(ProductName);
            Controls.Add(ProductID);
            Controls.Add(panel1);
            FormBorderStyle = FormBorderStyle.None;
            Name = "ManageProducts";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "ManageProducts";
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)productData).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Panel panel1;
        private Label label3;
        private Label label2;
        private Label label1;
        private Button button4;
        private Button button3;
        private Button button1;
        private TextBox ProductPrice;
        private TextBox ProductQuantity;
        private TextBox ProductName;
        private TextBox ProductID;
        private TextBox ProductDesceription;
        private DataGridView productData;
        private Panel panel2;
        private ComboBox Catcombo;
        private ComboBox searchCombo;
        private Button Search;
        private Button refresh;
    }
}