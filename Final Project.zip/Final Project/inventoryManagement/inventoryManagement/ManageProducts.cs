﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace inventoryManagement
{
    public partial class ManageProducts : Form
    {
        SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=""D:\Uni\OS Lab\Final Project\inventoryManagement\inventoryManagement\inventorydb.mdf"";Integrated Security=True");
        public ManageProducts()
        {
            InitializeComponent();
            this.Load += new EventHandler(ManageProducts_Load);

        }
        private void ManageProducts_Load(object sender, EventArgs e)
        {
            fillcategory();
            LoadProductData();
        }
        private void LoadProductData()
        {
            try
            {
                string query = "SELECT * FROM [Product]";
                SqlDataAdapter sda = new SqlDataAdapter(query, con);
                DataTable dt = new DataTable();
                sda.Fill(dt);
                productData.DataSource = dt;
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred: " + ex.Message);
            }
        }
        private void filterByCategory()
        {
            try
            {
                string query = "SELECT * FROM [Product] where ProdCat = '" + searchCombo.SelectedValue.ToString() + "'";
                SqlDataAdapter sda = new SqlDataAdapter(query, con);
                DataTable dt = new DataTable();
                sda.Fill(dt);
                productData.DataSource = dt;
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred: " + ex.Message);
            }
        }
        void fillcategory()
        {
            string query = "select * from [Category]";
            SqlCommand cmd = new SqlCommand(query, con);
            SqlDataReader rdr;
            try
            {
                con.Open();
                DataTable dt = new DataTable();
                dt.Columns.Add("CatName", typeof(string));
                rdr = cmd.ExecuteReader();
                dt.Load(rdr);
                Catcombo.ValueMember = "CatName";
                Catcombo.DataSource = dt;
                searchCombo.ValueMember = "CatName";
                searchCombo.DataSource = dt;
                con.Close();
            }
            catch
            {

            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                using (SqlCommand cmd = new SqlCommand("INSERT INTO [Product] (ProdId,ProdName, ProdQty,ProdPrice,Proddesc,ProdCat) VALUES (@ProdId, @ProdName, @ProdQty,@ProdPrice, @Proddesc, @ProdCat)", con))
                {
                    cmd.Parameters.AddWithValue("@ProdId", ProductID.Text);
                    cmd.Parameters.AddWithValue("@ProdName", ProductName.Text);
                    cmd.Parameters.AddWithValue("@ProdQty", ProductQuantity.Text);
                    cmd.Parameters.AddWithValue("@ProdPrice", ProductPrice.Text);
                    cmd.Parameters.AddWithValue("@Proddesc", ProductDesceription.Text);
                    cmd.Parameters.AddWithValue("@ProdCat", Catcombo.Text);
                    con.Open();
                    int rowsAffected = cmd.ExecuteNonQuery();
                    con.Close();
                    LoadProductData();
                    if (rowsAffected > 0)
                    {
                        MessageBox.Show("Product added successfully.");
                    }
                    else
                    {
                        MessageBox.Show("Product addition failed.");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred: " + ex.Message);
            }
        }

        private void ProductPrice_TextChanged(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void ProductName_TextChanged(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (ProductID.Text == "")
            {
                MessageBox.Show("please enter Product ID");
            }
            else
            {
                con.Open();
                string delQuery = "delete from [Product] where ProdId ='" + ProductID.Text + "'";
                SqlCommand cmd = new SqlCommand(delQuery, con);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Product deleted successfully.");
                con.Close();
                LoadProductData();
            }
        }

        private void ProductQuantity_TextChanged(object sender, EventArgs e)
        {

        }

        private void ProductDesceription_TextChanged(object sender, EventArgs e)
        {
        }

        private void Catcombo_SelectedIndexChanged(object sender, EventArgs e)
        {
        }

        private void Search_Click(object sender, EventArgs e)
        {
            filterByCategory();
        }

        private void refresh_Click(object sender, EventArgs e)
        {
            LoadProductData();
        }

        private void searchCombo_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            menu mn = new menu();
            mn.Show();
            this.Hide();
        }
    }
}
