﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace inventoryManagement
{
    public partial class ManageUsers : Form
    {
        public ManageUsers()
        {
            InitializeComponent();
        }
        SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=""D:\Uni\OS Lab\Final Project\inventoryManagement\inventoryManagement\inventorydb.mdf"";Integrated Security=True");
        private void LoadUserData()
        {
            try
            {
                string query = "SELECT * FROM [User]";
                SqlDataAdapter sda = new SqlDataAdapter(query, con);
                DataTable dt = new DataTable();
                sda.Fill(dt);
                userdata.DataSource = dt;
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred: " + ex.Message);
            }
        }
        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void ManageUsers_Load(object sender, EventArgs e)
        {
            LoadUserData();
        }

        private void button2_Click(object sender, EventArgs e)
        {
        }

        private void button4_Click(object sender, EventArgs e)
        {
            menu mn = new menu();
            mn.Show();
            this.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                using (SqlCommand cmd = new SqlCommand("INSERT INTO [User] (Uname, Ufullname, Upassword, Uphone) VALUES (@Uname, @Ufullname, @Upassword, @Uphone)", con))
                {
                    cmd.Parameters.AddWithValue("@Uname", username.Text);
                    cmd.Parameters.AddWithValue("@Ufullname", fullname.Text);
                    cmd.Parameters.AddWithValue("@Upassword", password.Text);
                    cmd.Parameters.AddWithValue("@Uphone", telephone.Text);
                    con.Open();
                    int rowsAffected = cmd.ExecuteNonQuery();
                    con.Close();
                    LoadUserData();
                    if (rowsAffected > 0)
                    {
                        MessageBox.Show("User added successfully.");
                    }
                    else
                    {
                        MessageBox.Show("User addition failed.");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred: " + ex.Message);
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (telephone.Text == "")
            {
                MessageBox.Show("please enter users phone number");
            }
            else
            {
                con.Open();
                string delQuery = "delete from [User] where Uphone ='" + telephone.Text + "'";
                SqlCommand cmd = new SqlCommand(delQuery, con);
                cmd.ExecuteNonQuery();
                MessageBox.Show("user deleted successfully.");
                con.Close();
                LoadUserData();
            }
        }

        private void label3_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void password_TextChanged(object sender, EventArgs e)
        {

        }

        private void telephone_TextChanged(object sender, EventArgs e)
        {
        }
    }
}
