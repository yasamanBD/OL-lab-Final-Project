﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace inventoryManagement
{
    public partial class menu : Form
    {
        public menu()
        {
            InitializeComponent();
        }

        private void label2_Click(object sender, EventArgs e)
        {
            ManageUsers usr = new ManageUsers();
            usr.Show();
            this.Hide();
        }

        private void label4_Click(object sender, EventArgs e)
        {
            ManageCategories ctr = new ManageCategories();
            ctr.Show();
            this.Hide();
        }

        private void label7_Click(object sender, EventArgs e)
        {
            ManageOrders ord = new ManageOrders();
            ord.Show();
            this.Hide();
        }

        private void label5_Click(object sender, EventArgs e)
        {
            ManageProducts prd = new ManageProducts();
            prd.Show();
            this.Hide();
        }

        private void label6_Click(object sender, EventArgs e)
        {
            ManageCustomers cust = new ManageCustomers();
            cust.Show();
            this.Hide();
        }

        private void menu_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form1 frm = new Form1();
            frm.Show();
            this.Hide();
        }
    }
}
